import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import java.sql.*;
import java.util.*;

public class ExpenseSplitterApp extends Application {

    private Connection conn;
    private VBox membersBox = new VBox(10);
    private VBox expensesBox = new VBox(10);

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        connectToDatabase();
        createTables();

        TabPane tabPane = new TabPane();
        tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);

        Tab membersTab = new Tab("👥 Members", membersTab());
        Tab expensesTab = new Tab("💸 Expenses", expensesTab());
        Tab summaryTab = new Tab("📊 Summary", summaryTab());

        tabPane.getTabs().addAll(membersTab, expensesTab, summaryTab);

        Scene scene = new Scene(tabPane, 700, 500);
        scene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());

        // Dynamic font scaling
        scene.widthProperty().addListener((obs, oldVal, newVal) -> {
            double fontSize = Math.max(12, newVal.doubleValue() / 50);
            scene.getRoot().setStyle("-fx-font-size: " + fontSize + "px;");
        });

        primaryStage.setScene(scene);
        primaryStage.setTitle("Expense Splitter App");
        primaryStage.show();
    }

    private VBox membersTab() {
        TextField nameField = createExpandingTextField("Enter member name");
        Button addBtn = new Button("➕ Add Member");
        addBtn.getStyleClass().add("action-button");
        addBtn.setOnAction(e -> {
            addMember(nameField.getText());
            nameField.clear();
            loadMembers();
        });

        HBox inputBox = new HBox(10, nameField, addBtn);
        inputBox.setAlignment(Pos.CENTER_LEFT);
        HBox.setHgrow(nameField, Priority.ALWAYS);

        loadMembers();

        VBox layout = new VBox(15,
                new Label("Add New Member"),
                inputBox,
                new Separator(),
                new Label("Current Members:"),
                membersBox
        );
        layout.setPadding(new Insets(15));
        return layout;
    }

    private void loadMembers() {
        membersBox.getChildren().clear();
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT name FROM members")) {
            while (rs.next()) {
                Label nameLabel = new Label("👤 " + rs.getString("name"));
                membersBox.getChildren().add(nameLabel);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private VBox expensesTab() {
        TextField descriptionField = createExpandingTextField("Description");
        TextField amountField = createExpandingTextField("Amount");
        TextField payerField = createExpandingTextField("Payer's Name");

        Button addExpenseBtn = new Button("➕ Add Expense");
        addExpenseBtn.getStyleClass().add("action-button");
        addExpenseBtn.setOnAction(e -> {
            try {
                addExpense(descriptionField.getText(), Double.parseDouble(amountField.getText()), payerField.getText());
                descriptionField.clear();
                amountField.clear();
                payerField.clear();
                loadExpenses();
            } catch (NumberFormatException ex) {
                // Optionally show error to user
            }
        });

        HBox inputBox = new HBox(10, descriptionField, amountField, payerField, addExpenseBtn);
        inputBox.setAlignment(Pos.CENTER_LEFT);
        HBox.setHgrow(descriptionField, Priority.ALWAYS);
        HBox.setHgrow(amountField, Priority.ALWAYS);
        HBox.setHgrow(payerField, Priority.ALWAYS);

        loadExpenses();

        VBox layout = new VBox(15,
                new Label("Add New Expense"),
                inputBox,
                new Separator(),
                new Label("All Expenses:"),
                expensesBox
        );
        layout.setPadding(new Insets(15));
        return layout;
    }

    private void loadExpenses() {
        expensesBox.getChildren().clear();
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT description, amount, payer FROM expenses")) {
            while (rs.next()) {
                String desc = rs.getString("description");
                double amt = rs.getDouble("amount");
                String payer = rs.getString("payer");
                expensesBox.getChildren().add(new Label("💰 " + payer + " paid ₹" + amt + " for " + desc));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private VBox summaryTab() {
        VBox summaryBox = new VBox(10);
        Button refreshBtn = new Button("🔄 Refresh Summary");
        refreshBtn.getStyleClass().add("action-button");
        refreshBtn.setOnAction(e -> {
            summaryBox.getChildren().clear();
            summaryBox.getChildren().addAll(calculateSummary());
        });

        VBox layout = new VBox(15, refreshBtn, new Separator(), summaryBox);
        layout.setPadding(new Insets(15));
        return layout;
    }

    private Label[] calculateSummary() {
        Map<String, Double> totalPaid = new HashMap<>();
        List<String> members = new ArrayList<>();
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT name FROM members")) {
            while (rs.next()) {
                String name = rs.getString("name");
                members.add(name);
                totalPaid.put(name, 0.0);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        int memberCount = members.size();
        if (memberCount == 0) return new Label[]{ new Label("No members to calculate summary.") };

        double totalExpenses = 0.0;
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT payer, amount FROM expenses")) {
            while (rs.next()) {
                String payer = rs.getString("payer");
                double amount = rs.getDouble("amount");
                totalExpenses += amount;
                totalPaid.put(payer, totalPaid.getOrDefault(payer, 0.0) + amount);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        double sharePerPerson = totalExpenses / memberCount;
        Map<String, Double> balances = new HashMap<>();
        for (String member : members) {
            double paid = totalPaid.getOrDefault(member, 0.0);
            balances.put(member, paid - sharePerPerson);
        }

        List<Map.Entry<String, Double>> creditors = new ArrayList<>();
        List<Map.Entry<String, Double>> debtors = new ArrayList<>();
        for (Map.Entry<String, Double> entry : balances.entrySet()) {
            if (entry.getValue() > 0.01) creditors.add(entry);
            else if (entry.getValue() < -0.01) debtors.add(entry);
        }

        List<Label> summary = new ArrayList<>();
        int i = 0, j = 0;
        while (i < debtors.size() && j < creditors.size()) {
            Map.Entry<String, Double> debtor = debtors.get(i);
            Map.Entry<String, Double> creditor = creditors.get(j);
            double oweAmount = Math.min(-debtor.getValue(), creditor.getValue());
            summary.add(new Label("➡️ " + debtor.getKey() + " owes " + creditor.getKey() + " ₹" + String.format("%.2f", oweAmount)));
            debtor.setValue(debtor.getValue() + oweAmount);
            creditor.setValue(creditor.getValue() - oweAmount);
            if (Math.abs(debtor.getValue()) < 0.01) i++;
            if (Math.abs(creditor.getValue()) < 0.01) j++;
        }

        if (summary.isEmpty()) {
            summary.add(new Label("✅ All balances are settled."));
        }

        return summary.toArray(new Label[0]);
    }

    private TextField createExpandingTextField(String prompt) {
        TextField field = new TextField();
        field.setPromptText(prompt);
        field.setMaxWidth(Double.MAX_VALUE);
        return field;
    }

    private void addMember(String name) {
        if (name == null || name.trim().isEmpty()) return;
        try (PreparedStatement pstmt = conn.prepareStatement("INSERT INTO members(name) VALUES(?)")) {
            pstmt.setString(1, name);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void addExpense(String description, double amount, String payer) {
        if (description == null || description.trim().isEmpty() ||
                payer == null || payer.trim().isEmpty() || amount <= 0) return;
        try (PreparedStatement pstmt = conn.prepareStatement("INSERT INTO expenses(description, amount, payer) VALUES(?, ?, ?)")) {
            pstmt.setString(1, description);
            pstmt.setDouble(2, amount);
            pstmt.setString(3, payer);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void connectToDatabase() {
        try {
            conn = DriverManager.getConnection("jdbc:sqlite:expenses.db");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void createTables() {
        try (Statement stmt = conn.createStatement()) {
            stmt.execute("CREATE TABLE IF NOT EXISTS members (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT)");
            stmt.execute("CREATE TABLE IF NOT EXISTS expenses (id INTEGER PRIMARY KEY AUTOINCREMENT, description TEXT, amount REAL, payer TEXT)");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
